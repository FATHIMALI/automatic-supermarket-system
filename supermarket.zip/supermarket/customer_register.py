#!C:/Users/THARANI/AppData/Local/Programs/Python/Python37-32/python.exe
print("content-type:text/html \r\n\r\n")

import cgi,os,smtplib
import pymysql,cgitb;cgitb.enable()

conn=pymysql.connect("localhost","root","","supermarket")
cur=conn.cursor()
s="""select max(id) from customer_details"""
cur.execute(s)
rec=cur.fetchone()

if rec[0]==None:
    n=0
else:
    n=rec[0]
if n<10:
   z="000"
elif n<100:
     z="00"
elif n<1000:
     z="0"
else:
     z=""
cusid="custid"+z+str(n+1)

print("""
<html>
<head>
  <meta charset="UTF-8">
  <title> Customer Registration Form</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="style.css">
	  <style>
	  html {
  font-size: 10px;
  tap-highlight-color: rgba(0, 0, 0, 0);
  box-sizing: border-box;
}
 
*, *:before, *:after {
  margin: 0;
  padding: 0;
  box-sizing: inherit;
}
 
body {
 
  font-family: 'PT Sans', sans-serif;
  font-size: 16px;
  line-height: 1.428571429;
  font-weight: 400;
  color: #fff;
  background: url(image/market2.jpeg) no-repeat center center fixed ; 
  background-size: cover;	
}

.navigation-bar {
    width: 100%; 
    height: 70px;	
    background-color: red; 
}
.logo {
    display: inline-block;
    vertical-align: top;
    width: 80px;
    height: 60px;
    margin-right: 20px;
    margin-top: 10px;
    border-radius: 60px;	
}
.auto
    {
	width:677px;
	height:60px;
	margin:0px;
	text-align:top;
	text-bottom:15pt;
	font-size:20pt;
	color:blue;
	margin-left: 80px;
	margin-top:-40px;
	}
.h-me
    {
	height:60px;
	width:677px;
	margin:0px;
	margin-left:1250px;
	text-align:top;
	text-bottom: 15pt;
	font-size: 15pt;
	margin-top: -60px;
	color:blue;
	outline: none;
}

.home
   {
    height:20px;
    width: 25px;
	margin-top:-60px;
	margin-left:1215px;	
}
 
.row {
  display: flex;
  align-items: center;
  justify-content: center;
}
 
.section {
  margin-top: 100px;
  background-color: #50C5FF;
  position: relative;
  overflow: hidden;
  display: flex;
  justify-content: center;
  flex-direction: column;
}
 
header,
main,
footer {
  display: block;
  position: relative;
  z-index: 1;
}
 
header {
  padding: 48px;
}
@media (max-width: 440px) {
  header {
    padding: 48px 24px;
  }
}
header > h3 {
  font-size: 44px;
  font-weight: 700;
  margin-bottom: 8px;
	text-align: center;
}
header > h4 {
  font-size: 22px;
  font-weight: 400;
  letter-spacing: 1px;
	text-align: center;
}
 
main {
  flex: 1;
  padding: 0 48px;
}
@media (max-width: 440px) {
  main {
    padding: 0 24px;
  }
}
 
footer {
  width: 100%;
  background-color: red;
  padding: 16px;
  align-self: center;
  text-align: center;
  margin-top: 32px;
}
footer a {
  color: #fff;
  font-weight: 700;
  text-decoration: none;
}
footer a:hover {
  text-decoration: underline;
}
 
form {
  height: 100%;
  display: flex;
  justify-content: center;
  flex-direction: column;
}
 
.label {
  color: rgba(226, 227, 232, 0.75);
  font-size: 16px;
}
 
small {
  display: none;
}
small.errorOnce {
  margin-top: 2px;
}
.tx1 {
	margin-top: 10px;
}
.form-item input[type="text"],
.form-item input[type="number"],
.form-item input[type="email"] {
  display: block;
  color: #E2E3E8;
  font-size: 16px;
  width: 100%;
  background-color: transparent;
  border: none;
  border-bottom: 1px solid black;
  padding: 8px 0;
  appearance: none;
  outline: none;
}
.form-item i {
  font-size: 12px;
  color: red;
}
 
.box-item {
  height: 60px;
  margin-bottom: 16px;
}
 

.submit {
  display: inline-block;
  font-size: 18px;
  font-weight: 700;
  letter-spacing: 1px;
  padding: 8px 48px;
  margin-top: 32px;
  border: 2px solid #075BB4;
  border-radius: 20px;
  cursor: pointer;
  transition: all ease .2s;
}
.submit:hover {
  background-color: red;
  border: 2px solid black;
}
.submit1{
  display: inline-block;
  font-size: 18px;
  font-weight: 700;
  letter-spacing: 1px;
  padding: 8px 48px;
  margin-top: 32px;
  border: 2px solid #075BB4;
  border-radius: 20px;
  cursor: pointer;
  transition: all ease .2s;
  margin-left: 50px;
}
.submit1:hover {
  background-color: red;
  border: 2px solid black;
}
 
.wave {
  position: absolute;
  top: 0;
  left: 50%;
  width: 800px;
  height: 800px;
  margin-top: -600px;
  margin-left: -400px;
  background: red;
  border-radius: 40%;  
  animation: shift 20s infinite linear;
  z-index: 0;
}
 
 
@keyframes shift{
  from{
    transform: rotate(360deg);
  }
}
  </style>
   <script>
   function submit()
	{
		
		var uname = document.getElementById("email").value;
		var pwd = document.getElementById("pwd1").value;
		var email=document.getElementById("em").value;
		var name1=document.getElementById("name").value;
		var phone=document.getElementById("phno").value;
		var pattern=/^\d{10}$/
		var alphaExp=/^[a-zA-Z]+$/;
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if(uname =='')
		{
			alert("please enter user name.");
		}
		else if(email=='')
		{
		  alert("please enter email id")
		  }
		else if(pwd=='')
		{
        	alert("enter the password");
		}
		else if(name1=='')
		 {
		   alert("please enter the name");
		   }
		 else if(!name1.match(alphaExp))
		    {
			  alert("please enter valid name");
			  }
		 else if(phone=='')
		   {
		     alert("please enter the phone no");
			}
		 else if(!phone.match(pattern))
		   {
		     alert("enter valid phone no");
			 }
		else if(!filter.test(uname))
		{
			alert("Enter valid username.");
		}
		else if(!filter.test(email))
		 {
		   alert("enter valid email id.");
		  }
		else if(pwd.length < 6 || pwd.length > 6)
		{
			alert("Password min and max length is 6.");
		}
		else
		{
	       alert('Thank You for Register');
  
			}
	}		
	
  </script>  
</head>
<body>
<nav class="navigation-bar">
    <img class="logo" src="images/image.webp">
	<h4 class="auto" style="color:white;">Automatic supermarket</h4>
	<img src="images/home.jpg" class="home"><a href="home.py" style="text-decoration:none;"><h6 class="h-me" style="color:white;">home</h6></a>
	</nav>

  <div class="row">
  <section class="section">
    <header>
      <h3>Register</h3>
      <h4>Please fill your information in this form</h4>
    </header>
    <main>
       <form action="#" method="post" onsubmit="validate()" enctype="multipart/form-data">
	    <div class="form-item box-item">""")
print("""		    <input type="text" name="cusid" class="tx1" id="cus" value='%s'>"""%(cusid))
print("""		 </div>
        <div class="form-item box-item">
          <input type="text" name="name" class="tx1" placeholder="Name" id="name">
        </div>
        <div class="form-item box-item">
          <input type="email" name="email" class="tx1" placeholder="Email" id="em">
        </div>
        <div class="form-item box-item">
          <input type="email" name="username1" placeholder="Username" id="email">
        </div>
        <div class="form-item-double box-item">
            <div class="form-item">
                <input type="text" name="password" placeholder="password" id="pwd1">
           </div>
        </div>
        <div class="form-item box-item">
          <input type="text" name="phone" placeholder="Phone" id="phno">
        </div>
        <div class="form-item box-item">
          <input type="file" name="profile">
        </div>
        <div class="form-item">
         <input type="submit" name="sub" onClick="submit()" value="Submit">
         <input type="button" onClick="location.href='home.py'" value="Cancel">
		  
		 </div>
    </form>  
    </main>
    <footer>
      <p>Already have an account? <a href="customer_login.py">Login</a></p>
    </footer>
    <i class="wave"></i>
  </section>
</div>

</body>

</html>



""")

f=cgi.FieldStorage()
pname=f.getvalue("name")
pem=f.getvalue("email")
puname=f.getvalue("username1")
ppwd=f.getvalue("password")
pph=f.getvalue("phone")
psubmit=f.getvalue("sub")
if psubmit!=None:
    pprofile=f['profile']
    if pprofile.filename:
        fn=os.path.basename(pprofile.filename)
        f=open('file/'+fn,'wb')
        f.write(pprofile.file.read())
        fromaddr='supermarket2105@gmail.com'
        password='2105market'
        toaddrs=pem
        msg="""welocome to my project!!!"""
        try:
            server=smtplib.SMTP('smtp.gmail.com:587')
            server.ehlo()
            server.starttls()
            server.login(fromaddr,password)
            server.sendmail(fromaddr,toaddrs,msg)
            server.quit()
            q = """insert into customer_details(customer_id,name,email,username,password,phone,profile)values('%s','%s','%s','%s','%s','%s','%s')""" %(cusid,pname,pem,puname,ppwd,pph,fn)
            cur.execute(q)
            conn.commit()
            print("""<script>alert("mail send successfully...");</script>""")
        except:
              print("""<script>alert("mail not send...");</script>""")
        conn.close()